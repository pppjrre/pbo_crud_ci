<html>
	<head>
		<title>Login System</title>
	</head>
	<body>
		<form action="" method="post">
		<table align="center">
			<tr>
				<td>Username</td>
				<td><input type="text" name="txt_user"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="Password" name="txt_pass"></td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="submit" name="btn_login" value="Login">
				</td>
			</tr>
		</table>
		</form>
	</body>
</html>